# Missions List

## Operation Desert Ghost (Middle East)
- Infiltrate a fortified enemy compound to retrieve stolen intel.

## Operation Nightfall (Europe)
- Sabotage weapons shipment in a snowy European city.

## Operation Jungle Phantom (South America)
- Eliminate a cartel warlord in dense jungle terrain.

## SECRET OPS: Shadow Protocol (Global)
- Stop a nuclear exchange, only accessible after all main ops.

## More missions...
- Expand with unique objectives, map variety, and difficulty scaling.

# Rewards

- Credits for in-game store
- Exclusive weapons/skins
- Achievements/trophies
- Unlockable gadgets and upgrades
- Story cinematics

# Playable Super Agent

- Oistarian: Stealth, hacking, martial arts, and advanced gear